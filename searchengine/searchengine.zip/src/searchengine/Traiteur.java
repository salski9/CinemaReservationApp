package searchengine; 
import java.util.List;


public interface  Traiteur {	
	public List <String> traiter(List<String> fileToString);
}
