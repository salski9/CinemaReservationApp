package searchengine;
import java.util.ArrayList;
import java.util.List;

public class AnaylseurMotVide {
	List <String> l = new ArrayList<String> ();
	public List <String> getAnalyseDecompose() {
        return l;
	}
	public void analyser (String chainessMotVide) {
		
		
	}
}
