package com.enit.controller;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;

import jakarta.ejb.EJB;
import jakarta.ejb.SessionContext;
import jakarta.persistence.Query;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.enit.entities.Compte;
import com.enit.entities.Film;
import com.enit.entities.SalleProg;
import com.enit.entities.Seance;
import com.enit.service.IRemoteCinema;
import com.enit.service.IRemoteUtilisateur;
import com.enit.service.SoldeNegatifException;
import com.enit.service.UserNotFoundException;

@WebServlet(name = "cs", urlPatterns = {"/controleur"})
public class ControleurServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private ServletContext context;

    @EJB
    private IRemoteCinema metierCinema;

    @EJB
    private IRemoteUtilisateur metierUtilisateur;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        context = request.getSession().getServletContext();
    	String filmId = request.getParameter("filmId");
    	String name = request.getParameter("name");
        String pwd = request.getParameter("password");
        
        
        String page = request.getParameter("page");
        
     // Determine the target page (default is home.jsp)
        
        if (page == null || page.isEmpty()) {
            page = "home.jsp"; // Default page
        }
        
        if (page.equals("home.jsp")) {
        	
        	// Fetch list of films
	        Set<Film> setFilms = metierCinema.list();
	        List<Film> listeFilm = new ArrayList<>(setFilms);
	        listeFilm.sort(Comparator.comparing(film -> Integer.valueOf(film.getId_film())));
	        
	        
	        

	        // Set attributes for JSP
	        context.setAttribute("TousLesFilms", listeFilm);
	        //context.setAttribute("TousLesSalleDeProg", listSalleProgs);
        }else if(page.equals("user.jsp")) {
        	 int id;
			try {
				id = metierUtilisateur.init(name, pwd);
				Compte compte = metierUtilisateur.getCompte(id);
				context.setAttribute("compte", compte);
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
        	
        }else if(page.equals("reserver.jsp")) {
        	
        	
	        //context.setAttribute("TousLesSalleDeProg", listSalleProgs);
        	 Film film = metierCinema.findFilm(Integer.parseInt(filmId));
        	 /*List<Film> listeFilms = new ArrayList<Film>();
        	 listeFilms.add(film);*/
        	 context.setAttribute("film", film);
        	 
        	 Set<SalleProg> setSalleProgs = metierCinema.getAllSalleProg();
 	         List<SalleProg> listSalleProgs = new ArrayList<>(setSalleProgs);
 	         context.setAttribute("TousLesSalleDeProg", listSalleProgs);
        	
        }
        
	        // Forward to JSP page
	        context.getRequestDispatcher("/" + page).forward(request, response);
	        
        
    }


	
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        context = request.getSession().getServletContext();
        String name = request.getParameter("name");
        String pwd = request.getParameter("password");
        String action = request.getParameter("action");
        String targetPage = "home.jsp"; // Default page
        String filmId = request.getParameter("filmId");
        if (action != null) {
            if (action.equals("ajouter")) {
                // Handle adding a film
            	targetPage = "listeFilm.jsp";
                String nomFilm = request.getParameter("nom");
                String realisateurFilm = request.getParameter("realisateur");
                String dateProj = request.getParameter("dateProj");
                LocalDate projectionDate = LocalDate.parse(dateProj);
                Film nvFilm = new Film(nomFilm, realisateurFilm, projectionDate);
                metierCinema.update(nvFilm);

                List<Film> listeFilms = new ArrayList<>(metierCinema.list());
                listeFilms.sort(Comparator.comparing(film -> Integer.valueOf(film.getId_film())));
                context.setAttribute("TousLesFilms", listeFilms);

            }else if (action.equals("login")) {
            	 
                //name = request.getParameter("name");
                //pwd = request.getParameter("password");
                try {
                	targetPage = "user.jsp";
                    int id = metierUtilisateur.init(name, pwd);
                    Compte compte = metierUtilisateur.getCompte(id);
                    
                    request.setAttribute("compte", compte);
                    request.setAttribute("isLoggedIn", true);
                } catch (UserNotFoundException e) {
                	targetPage = "login.jsp"; 
                    request.setAttribute("isLoggedIn", false);
                    request.setAttribute("errorMsg", "Nom ou mot de passe incorrect.");
                }
                
            }

            else if (action.equals("debiter")) {
                // Handle debiting
            	float debitAmount = Float.parseFloat(request.getParameter("debitAmount"));
                try {
                	metierUtilisateur.debiter(debitAmount);
                    int id = metierUtilisateur.init(name, pwd);
                    Compte compte = metierUtilisateur.getCompte(id);
                    
                    request.setAttribute("successMsg", "Le montant de " + debitAmount + " € a été débité avec succès !");
                    context.setAttribute("compte", compte);
                    targetPage = "user.jsp"; // Redirect to user.jsp on success
                
                } catch (UserNotFoundException e) {
                    request.setAttribute("errorMsg", "Erreur : Utilisateur non trouvé. Veuillez vous authentifier.");
                } catch (Exception e) {
                    request.setAttribute("errorMsg", "Une erreur inattendue s'est produite : " + e.getMessage());
                }
               
            }
            else if (action.equals("reserver")){
            	
            	
            	int idFilm = Integer.parseInt(filmId);
            	Film film = metierCinema.findFilm(idFilm); 
            	 List<Film> listeFilms = new ArrayList<Film>();
            	 listeFilms.add(film);
            	request.setAttribute("liste", listeFilms);	
            	targetPage = "reserver.jsp";
            	
        }else if (action.equals("register")) {
        	String nameNv = request.getParameter("name");
            String pwdNv = request.getParameter("password");
            metierUtilisateur.createCompte(nameNv, pwdNv);
			targetPage="home.jsp"; 
        }

        // Forward to the target page
        context.getRequestDispatcher("/" + targetPage).forward(request, response);
    }
}
}

